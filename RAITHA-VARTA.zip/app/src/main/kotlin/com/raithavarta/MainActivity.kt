package com.raithavarta

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.raithavarta.ui.navigation.RaithaVartaNavigation
import com.raithavarta.ui.navigation.Screen
import com.raithavarta.ui.theme.RaithaVartaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RaithaVartaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    val navController = rememberNavController()
                    var showOnboarding by remember { mutableStateOf(true) }
                    
                    RaithaVartaNavigation(
                        navController = navController,
                        startDestination = if (showOnboarding) Screen.Onboarding.route else Screen.Home.route
                    )
                }
            }
        }
    }
}
